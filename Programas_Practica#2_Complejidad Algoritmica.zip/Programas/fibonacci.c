#include <stdio.h>
#include <time.h>

long long fibonacci(int n) {
    if (n <= 1) {
        return n;
    }
    return fibonacci(n - 1) + fibonacci(n - 2);
}

void run_fibonacci(int n) {
    clock_t start = clock();
    fibonacci(n);
    clock_t end = clock();
    
    double time_spent = (double)(end - start) / CLOCKS_PER_SEC;
    
    printf("n = %d\n", n);
    printf("  Tiempo de ejecucion: %f segundos\n", time_spent);
    // La memoria es la de la pila de recursi�n, O(n), pero muy peque�a en bytes.
    printf("  Memoria estimada: O(n) en pila, consumo muy bajo\n");
}

int main() {
    int i;
	for ( i = 5; i <= 20; i += 5) {
        run_fibonacci(i);
    }
    run_fibonacci(20);
    return 0;
}
