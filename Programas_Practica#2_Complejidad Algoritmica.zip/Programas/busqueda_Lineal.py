import time
import tracemalloc

def linear_search(arr, target):
    """
    Realiza una búsqueda lineal para encontrar el target en el arreglo arr.
    """
    for i in range(len(arr)):
        if arr[i] == target:
            return i  # Retorna el índice si lo encuentra
    return -1 # Retorna -1 si no lo encuentra

def run_linear_search(n):
    """
    Prepara los datos, ejecuta y mide el rendimiento de la búsqueda lineal.
    """
    # Creamos un arreglo de 0 a n-1
    arr = list(range(n))
    # El peor caso es buscar un elemento que no está
    target = -1 
    
    tracemalloc.start()
    start_time = time.time()
    
    linear_search(arr, target)
    
    end_time = time.time()
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    
    print(f"n = {n}")
    print(f"  Tiempo de ejecución: {end_time - start_time:.6f} segundos")
    print(f"  Pico de memoria: {peak / 1024:.2f} KB")

# Ejecutamos para los diferentes tamaños
run_linear_search(10**3)
run_linear_search(10**4)
run_linear_search(10**5)