#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int binary_search(int arr[], int n, int target) {
    int low = 0, high = n - 1;
    while (low <= high) {
        int mid = low + (high - low) / 2; // Evita overflow para n�meros muy grandes
        if (arr[mid] < target) {
            low = mid + 1;
        } else if (arr[mid] > target) {
            high = mid - 1;
        } else {
            return mid;
        }
    }
    return -1;
}

void run_binary_search(int n) {
    int* arr = (int*)malloc(n * sizeof(int));
    int i;
	for ( i = 0; i < n; i++) arr[i] = i; // Arreglo ordenado
    
    int target = -1;

    clock_t start = clock();
    binary_search(arr, n, target);
    clock_t end = clock();
    
    double time_spent = (double)(end - start) / CLOCKS_PER_SEC;
    
    printf("n = %d\n", n);
    printf("  Tiempo de ejecucion: %f segundos\n", time_spent);
    printf("  Memoria estimada: %.2f KB\n\n", (double)(n * sizeof(int)) / 1024.0);

    free(arr);
}

int main() {
    run_binary_search(1000);	//10n^3
    run_binary_search(10000);	//10n^4
    run_binary_search(100000);	//10n^5
    return 0;
}
