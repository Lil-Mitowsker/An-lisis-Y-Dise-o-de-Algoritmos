import time
import tracemalloc
import random

def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        # La bandera swapped optimiza para arreglos casi ordenados
        swapped = False
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                swapped = True
        if not swapped:
            break

def run_bubble_sort(n):
    # El peor caso es un arreglo ordenado en orden inverso
    arr = list(range(n, 0, -1))
    
    tracemalloc.start()
    start_time = time.time()
    
    bubble_sort(arr)
    
    end_time = time.time()
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    
    print(f"n = {n}")
    print(f"  Tiempo de ejecución: {end_time - start_time:.4f} segundos")
    print(f"  Pico de memoria: {peak / 1024:.2f} KB")

run_bubble_sort(10**3)
run_bubble_sort(10**4)
# run_bubble_sort(10**5) # ¡Esto tardaría DEMASIADO!