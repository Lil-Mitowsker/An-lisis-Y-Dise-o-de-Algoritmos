import time
import tracemalloc
import sys

# Aumentamos el límite de recursión para valores más altos
sys.setrecursionlimit(2000)

def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n-1) + fibonacci(n-2)

def run_fibonacci(n):
    tracemalloc.start()
    start_time = time.time()
    
    fibonacci(n)
    
    end_time = time.time()
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    
    print(f"n = {n}")
    print(f"  Tiempo de ejecución: {end_time - start_time:.6f} segundos")
    print(f"  Pico de memoria: {peak / 1024:.2f} KB")

for i in range(5, 21, 5):
    run_fibonacci(i)
run_fibonacci(25) # Un valor adicional para ver el salto
run_fibonacci(30)