import time
import tracemalloc

def binary_search(arr, target):
    low = 0
    high = len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] < target:
            low = mid + 1
        elif arr[mid] > target:
            high = mid - 1
        else:
            return mid
    return -1

def run_binary_search(n):
    arr = list(range(n)) # El arreglo ya está ordenado
    target = -1 # Peor caso
    
    tracemalloc.start()
    start_time = time.time()
    
    binary_search(arr, target)
    
    end_time = time.time()
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    
    print(f"n = {n}")
    print(f"  Tiempo de ejecución: {end_time - start_time:.8f} segundos")
    print(f"  Pico de memoria: {peak / 1024:.2f} KB")

run_binary_search(10**3)
run_binary_search(10**4)
run_binary_search(10**5)