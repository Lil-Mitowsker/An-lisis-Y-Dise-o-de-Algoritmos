#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Funci�n de b�squeda lineal
int linear_search(int arr[], int n, int target) {
    int i;
	for ( i = 0; i < n; i++) {
        if (arr[i] == target) {
            return i;
        }
    }
    return -1;
}

void run_linear_search(int n) {
    // Reservar memoria para el arreglo
    int* arr = (int*)malloc(n * sizeof(int));
    if (arr == NULL) {
        printf("Error al reservar memoria.\n");
        return;
    }

    // Llenar el arreglo de 0 a n-1
    int i;
	for ( i = 0; i < n; i++) {
        arr[i] = i;
    }
    
    // El peor caso: un elemento que no existe
    int target = -1;

    clock_t start = clock();
    linear_search(arr, n, target);
    clock_t end = clock();
    
    double time_spent = (double)(end - start) / CLOCKS_PER_SEC;
    
    printf("n = %d\n", n);
    printf("  Tiempo de ejecucion: %f segundos\n", time_spent);
    printf("  Memoria estimada: %.2f KB\n\n", (double)(n * sizeof(int)) / 1024.0);

    free(arr);
}

int main() {
    run_linear_search(1000);   //10n^3
    run_linear_search(10000);  //10n^4
    run_linear_search(100000); //10n^5
    return 0;
}
