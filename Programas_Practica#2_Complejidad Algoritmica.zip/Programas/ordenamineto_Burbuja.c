#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void swap(int* xp, int* yp) {
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void bubble_sort(int arr[], int n) {
	int i, j;
    for ( i = 0; i < n-1; i++) {
        for ( j = 0; j < n-i-1; j++) {
            if (arr[j] > arr[j+1]) {
                swap(&arr[j], &arr[j+1]);
            }
        }
    }
}

void run_bubble_sort(int n) {
    int* arr = (int*)malloc(n * sizeof(int));
    // Peor caso: arreglo en orden inverso
    int i;
    for ( i = 0; i < n; i++) arr[i] = n - i;

    clock_t start = clock();
    bubble_sort(arr, n);
    clock_t end = clock();
    
    double time_spent = (double)(end - start) / CLOCKS_PER_SEC;
    
    printf("n = %d\n", n);
    printf("  Tiempo de ejecuci�n: %f segundos\n", time_spent);
    printf("  Memoria estimada: %.2f KB\n", (double)(n * sizeof(int)) / 1024.0);

    free(arr);
}

int main() {
    run_bubble_sort(1000);
    run_bubble_sort(10000);
    run_bubble_sort(100000);
    return 0;
}
