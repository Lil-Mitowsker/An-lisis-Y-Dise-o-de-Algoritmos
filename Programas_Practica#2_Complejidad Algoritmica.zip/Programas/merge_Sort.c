#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void merge(int arr[], int l, int m, int r) {
    int i, j, k;
    int n1 = m - l + 1;
    int n2 = r - m;

    int *L = (int*)malloc(n1 * sizeof(int));
    int *R = (int*)malloc(n2 * sizeof(int));

    for (i = 0; i < n1; i++) L[i] = arr[l + i];
    for (j = 0; j < n2; j++) R[j] = arr[m + 1 + j];

    i = 0; j = 0; k = l;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i]; i++;
        } else {
            arr[k] = R[j]; j++;
        }
        k++;
    }

    while (i < n1) { arr[k] = L[i]; i++; k++; }
    while (j < n2) { arr[k] = R[j]; j++; k++; }
    
    free(L); free(R);
}

void merge_sort(int arr[], int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;
        merge_sort(arr, l, m);
        merge_sort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}

void run_merge_sort(int n) {
    int* arr = (int*)malloc(n * sizeof(int));
    int i;
	for ( i = 0; i < n; i++) arr[i] = rand() % n;

    clock_t start = clock();
    merge_sort(arr, 0, n - 1);
    clock_t end = clock();
    
    double time_spent = (double)(end - start) / CLOCKS_PER_SEC;
    
    printf("n = %d\n", n);
    printf("  Tiempo de ejecucion: %f segundos\n", time_spent);
    // Estimaci�n: Arreglo original + arreglos temporales (aprox. el doble del original)
    printf("  Memoria estimada: %.2f KB\n\n", (double)(2 * n * sizeof(int)) / 1024.0);

    free(arr);
}

int main() {
    srand(time(NULL));
    run_merge_sort(1000);
    run_merge_sort(10000);
    run_merge_sort(100000);
    return 0;
}
