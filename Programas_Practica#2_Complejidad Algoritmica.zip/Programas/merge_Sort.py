import time
import tracemalloc
import random

def merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr)//2
        L = arr[:mid]
        R = arr[mid:]

        merge_sort(L)
        merge_sort(R)

        i = j = k = 0
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                arr[k] = L[i]
                i += 1
            else:
                arr[k] = R[j]
                j += 1
            k += 1

        while i < len(L):
            arr[k] = L[i]
            i += 1
            k += 1
        while j < len(R):
            arr[k] = R[j]
            j += 1
            k += 1

def run_merge_sort(n):
    arr = [random.randint(0, n) for _ in range(n)] # Peor caso es aleatorio
    
    tracemalloc.start()
    start_time = time.time()
    
    merge_sort(arr)
    
    end_time = time.time()
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    
    print(f"n = {n}")
    print(f"  Tiempo de ejecución: {end_time - start_time:.4f} segundos")
    print(f"  Pico de memoria: {peak / 1024:.2f} KB")

run_merge_sort(10**3)
run_merge_sort(10**4)
run_merge_sort(10**5)